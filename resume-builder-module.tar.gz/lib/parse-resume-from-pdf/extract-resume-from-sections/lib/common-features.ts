export function isBold(item: any): boolean {
  return item.bold || false;
}