export const initialEducation = {
  school: "",
  degree: "",
  date: "",
  gpa: "",
  descriptions: []
};

export const initialWorkExperience = {
  company: "",
  jobTitle: "",
  date: "",
  descriptions: []
};